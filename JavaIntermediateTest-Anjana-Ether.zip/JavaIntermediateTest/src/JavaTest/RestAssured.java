package JavaTest;

public class RestAssured {
	/*
	 * Write a program that will remove a given characters from the string (String =
	 * �REST ASSURED� , remove characters �ST� ) Write a program to compare two
	 * strings using JAVA Program
	 */
	public void compareStrings(String str1, String str2) {// method to compare strings
		if (str1.equals(str2))
			System.out.println("The strings are the same");
		else if (str1.equalsIgnoreCase(str2))
			System.out.println("The Strings are equal but of different case");
		else
			System.out.println("The strings are not equal");
	}

	public String removeChar(String str1, String c) {
		String str2 = str1.replace(c, "");
		return str2;
	}

	public static void main(String args[]) {
		RestAssured rA = new RestAssured();
		String str1 = "REST ASSURED";
		rA.compareStrings("Anjana", "ANJANA");
		rA.compareStrings("Anjana", "Anjana");
		rA.compareStrings("Anjana", "AnjanaS");
		str1 = rA.removeChar(str1, "S");
		str1 = rA.removeChar(str1, "T");
		System.out.println("String after removing S and T -" + str1);
	}
}

/*
 * OUTPUT:
 * The Strings are equal but of different case 
 * The strings are the same
 * The strings are not equal 
 * String after removing S and T -RE AURED
 */