package JavaTest;

public class OopsConcepts {
	/*
	 * Write a program to demonstrate constructor, encapsulation and Inheritance .
	 */
	private int aVariable;

	public OopsConcepts(int a) {
		aVariable = a;
	}

	public void printVal() {

		System.out.println("The variable was initialised to " + aVariable);
	}
}
