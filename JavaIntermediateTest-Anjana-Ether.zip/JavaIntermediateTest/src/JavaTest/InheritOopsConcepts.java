package JavaTest;

public class InheritOopsConcepts extends OopsConcepts {
	public InheritOopsConcepts(int a) {
		super(a);
		// TODO Auto-generated constructor stub
	}

	public static void main(String args[]) {
		InheritOopsConcepts iOops = new InheritOopsConcepts(10);
		iOops.printVal(); // inheritance helped in accessing the printVal method
	}

}

/*
 * OUTPUT: The variable was initialized to 10
 */