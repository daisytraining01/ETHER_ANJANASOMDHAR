package JavaTest;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class DupliHashSet {
	/*
	 * Write a program to remove duplicate values from the hash set
	 */
	public void removeDupli(List<Integer> list2) {
		HashSet<Integer> set = new HashSet<Integer>(list2);
		System.out.println("The hash set without duplicate values is = " + set);// Hash set removes duplicate values
	}

	public static void main(String args[]) {
		DupliHashSet dupli = new DupliHashSet();
		List<Integer> list1 = new ArrayList<Integer>();
		list1.add(1);
		list1.add(2);
		list1.add(1);
		list1.add(2);
		list1.add(2);
		list1.add(3);
		System.out.println("The array List is as follows " + list1);
		dupli.removeDupli(list1);
	}
}
/*
 * OUTPUT:
 * The array List is as follows [1, 2, 1, 2, 2, 3] 
 * The hash set without duplicate values is = [1, 2, 3]
 */