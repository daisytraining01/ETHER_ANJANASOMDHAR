package JavaTest;

interface AreaInterface {
	public void area(int a);

	public void area(int a, int b);

	public void imple();
}

public class MethOverloading implements AreaInterface {
//	Write a program to illustrate method overloading and Interface
	@Override
	public void imple() {
		System.out.println("Interface Implemented");
	}

	@Override
	public void area(int a) {
		System.out.println("Area of square = " + a * a);
	}

	@Override
	public void area(int a, int b) {// same method name with different arguements-method overloading
		System.out.println("Area of rectangle = " + a * b);
	}

	public static void main(String args[]) {
		MethOverloading mO = new MethOverloading();
		mO.area(5);
		mO.area(2, 6);
		mO.imple();
	}

}

/*
 * OUTPUT: 
 * Area of square = 25 
 * Area of rectangle = 12 
 * Interface Implemented
 */
