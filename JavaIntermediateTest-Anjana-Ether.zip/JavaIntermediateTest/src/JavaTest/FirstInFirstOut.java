package JavaTest;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class FirstInFirstOut {
	/*
	 * Write a program to demonstrate First In First Out and Last In First Out
	 * concept demonstration
	 */
	public static void main(String[] args) {
		Stack<Integer> stack = new Stack<Integer>();
		Queue<Integer> queue = new LinkedList<>();
		queue.add(1);
		queue.add(2);
		queue.add(3);
		System.out.println("Element at the top of the queue is " + queue.peek() + "\nHence Queue follows FIFO");
		stack.add(1);
		stack.add(2);
		stack.add(3);
		System.out.println("Element at the top of the stack is " + stack.peek() + "\nHence Stack follows LIFO");
	}
}
/*
 * OUTPUT: 
 * Element at the top of the stack is 3 
 * Hence Stack follows LIFO 
 * Element at the top of the queue is 1 
 * Hence Queue follows FIFO
 */