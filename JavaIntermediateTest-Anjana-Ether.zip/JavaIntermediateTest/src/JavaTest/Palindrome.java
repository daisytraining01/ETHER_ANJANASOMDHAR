package JavaTest;

public class Palindrome {
	// Write a method to check if input string is Palindrome?

	public static void main(String args[]) {
		String palin = "Malayalam"; //Also tried with Tamil
		String check = "";
		for (int i = palin.length() - 1; i >= 0; i--) {
			check = check + palin.charAt(i);
		}
		if (palin.equalsIgnoreCase(check)) {
			System.out.println("The string " + palin + " is a palindrome");
		} else {
			System.out.println("The string " + palin + " is not a palindrome");
		}
	}
}
/*
 * OUTPUT1:
 * 
 * The string Malayalam is a palindrome
 * 
 * OUTPUT2:
 * 
 * The string Tamil is not a palindrome
 */
