package JavaTest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class PrintAlternateTextFromFile {
	// Write a program to read all the lines from the text file. While printing,
	// print only the alternate lines.
	public static void main(String[] args) throws Exception {
		File file = new File("D:\\AlternateLines.txt");
		BufferedReader alternateRead = new BufferedReader(new FileReader(file));
		int count = 0;
		String st;
		while ((st = alternateRead.readLine()) != null) {
			if (count % 2 == 0)
				System.out.println(st);
			count++;
		}
	}
}
/*
 * FILE CONTENTS: Maveric Systems Maveric Systems is an engineering services
 * company founded in 2000. It works across digital platforms, banking
 * solutions, data technologies, and regulatory systems. Maveric Systems has a
 * dedicated offshore delivery and research center in Chennai, India.
 * 
 * OUTPUT: Maveric Systems It works across digital platforms, banking solutions,
 * data technologies, and regulatory systems.
 */